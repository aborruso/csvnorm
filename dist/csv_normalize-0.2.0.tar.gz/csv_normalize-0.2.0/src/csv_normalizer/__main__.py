"""Entry point for python -m csv_normalizer."""

from csv_normalizer.cli import main

if __name__ == "__main__":
    main()
